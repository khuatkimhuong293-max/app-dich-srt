/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { GoogleGenAI } from "@google/genai";
import { 
  Upload, 
  FileText, 
  Download, 
  Languages, 
  Settings, 
  CheckCircle2, 
  AlertCircle, 
  Loader2,
  ChevronRight,
  Trash2,
  Play,
  History as HistoryIcon,
  Clock,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// --- Constants & Types ---

const MODEL_NAME = "gemini-3-flash-preview";

type TranslationStyle = "basic" | "advanced" | "technical";

interface SrtBlock {
  index: string;
  time: string;
  content: string;
}

interface TranslationTab {
  id: string;
  name: string;
  file: File | null;
  originalContent: string;
  translatedContent: string;
  isTranslating: boolean;
  progress: number;
  style: TranslationStyle;
  error: string | null;
  originalBlocks: SrtBlock[];
  translatedBlocks: SrtBlock[];
  viewMode: "comparison" | "raw";
}

const createNewTab = (name = "Mới"): TranslationTab => ({
  id: Math.random().toString(36).substr(2, 9),
  name,
  file: null,
  originalContent: "",
  translatedContent: "",
  isTranslating: false,
  progress: 0,
  style: "advanced",
  error: null,
  originalBlocks: [],
  translatedBlocks: [],
  viewMode: "comparison",
});

const PROMPTS: Record<TranslationStyle, string> = {
  basic: `Tôi sẽ gửi cho bạn nội dung của một tệp phụ đề .srt bằng tiếng Trung. Hãy dịch nó sang tiếng Việt.
Yêu cầu:
- Giữ nguyên các mốc thời gian và số thứ tự đoạn (VD: 00:00:10,000 --> 00:00:12,000).
- Dịch nghĩa tự nhiên, trôi chảy, phù hợp với văn phong nói của người Việt.
- Không tự ý gộp dòng hoặc xóa dòng.
- Trả về kết quả dưới định dạng mã (code block) để tôi dễ sao chép.
- Chỉ trả về nội dung đã dịch, không kèm lời giải thích.`,

  advanced: `Bạn là một chuyên gia dịch thuật phim chuyên nghiệp. Hãy dịch tệp .srt tiếng Trung dưới đây sang tiếng Việt.
Yêu cầu chi tiết:
- Văn phong: Gần gũi, đời thường nhưng phải khớp với ngữ cảnh của phim.
- Ngôi xưng: Hãy dựa vào nội dung để chọn ngôi xưng phù hợp (như anh/em, tôi/cô, cậu/tớ).
- Kỹ thuật: Tuyệt đối không thay đổi cấu trúc thời gian của tệp .srt. Giữ nguyên định dạng 00:00:00,000.
- Độ dài: Cố gắng dịch ngắn gọn để người xem kịp đọc, tránh những câu quá dài so với thời gian hiển thị.
- Chỉ trả về nội dung đã dịch, không kèm lời giải thích.`,

  technical: `Dịch file phụ đề .srt này từ tiếng Trung sang tiếng Việt. Đây là video về chủ đề chuyên ngành.
Yêu cầu:
- Đảm bảo các thuật ngữ chuyên ngành được dịch chính xác.
- Giữ nguyên các thông số kỹ thuật và mốc thời gian.
- Xuất kết quả ở định dạng văn bản thô để tôi lưu lại thành file .srt.
- Chỉ trả về nội dung đã dịch, không kèm lời giải thích.`
};

// --- Helper Functions ---

function parseSrt(text: string): SrtBlock[] {
  const blocks: SrtBlock[] = [];
  const rawBlocks = text.trim().split(/\n\s*\n/);
  
  for (const block of rawBlocks) {
    const lines = block.split("\n");
    if (lines.length >= 3) {
      blocks.push({
        index: lines[0].trim(),
        time: lines[1].trim(),
        content: lines.slice(2).join("\n").trim()
      });
    }
  }
  return blocks;
}

function stringifySrt(blocks: SrtBlock[]): string {
  return blocks.map(b => `${b.index}\n${b.time}\n${b.content}`).join("\n\n");
}

// --- Components ---

export default function App() {
  const [tabs, setTabs] = useState<TranslationTab[]>(() => [createNewTab("Dịch thuật 1")]);
  const [activeTabId, setActiveTabId] = useState<string>(() => tabs?.[0]?.id || "");

  useEffect(() => {
    if (tabs.length > 0 && !activeTabId) {
      setActiveTabId(tabs[0].id);
    }
  }, [tabs, activeTabId]);

  const currentTab = tabs.find(t => t.id === activeTabId) || tabs[0];

  const updateTab = (id: string, updates: Partial<TranslationTab>) => {
    setTabs(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));
  };

  const addTab = () => {
    const newTab = createNewTab(`Dịch thuật ${tabs.length + 1}`);
    setTabs([...tabs, newTab]);
    setActiveTabId(newTab.id);
  };

  const closeTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (tabs.length === 1) {
      const newTab = createNewTab("Dịch thuật 1");
      setTabs([newTab]);
      setActiveTabId(newTab.id);
      return;
    }
    const newTabs = tabs.filter(t => t.id !== id);
    setTabs(newTabs);
    if (activeTabId === id) {
      const currentIndex = tabs.findIndex(t => t.id === id);
      const nextTab = newTabs[currentIndex] || newTabs[currentIndex - 1];
      setActiveTabId(nextTab.id);
    }
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isDragging, setIsDragging] = useState(false);

  const [activeTab, setActiveTab] = useState<"translate" | "history" | "settings" | "glossary">("translate");
  const [glossary, setGlossary] = useState<{ zh: string; vi: string }[]>(() => {
    const saved = localStorage.getItem("srt_glossary");
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem("srt_glossary", JSON.stringify(glossary));
  }, [glossary]);

  const [settings, setSettings] = useState({
    chunkSize: 50,
    autoDownload: false,
    showTimestamps: true,
  });

  const [history, setHistory] = useState<{ id: string; name: string; date: string; size: string }[]>(() => {
    const saved = localStorage.getItem("srt_history");
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem("srt_history", JSON.stringify(history));
  }, [history]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.name.endsWith(".srt")) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        updateTab(activeTabId, {
          file: selectedFile,
          name: selectedFile.name,
          originalContent: content,
          originalBlocks: parseSrt(content),
          error: null
        });
      };
      reader.readAsText(selectedFile);
    } else if (selectedFile) {
      updateTab(activeTabId, { error: "Vui lòng chọn tệp .srt hợp lệ." });
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile && droppedFile.name.endsWith(".srt")) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        updateTab(activeTabId, {
          file: droppedFile,
          name: droppedFile.name,
          originalContent: content,
          originalBlocks: parseSrt(content),
          error: null
        });
      };
      reader.readAsText(droppedFile);
    } else if (droppedFile) {
      updateTab(activeTabId, { error: "Vui lòng chọn tệp .srt hợp lệ." });
    }
  };

  const translate = async () => {
    const tab = currentTab;
    if (!tab.originalContent || tab.isTranslating) return;
    
    updateTab(tab.id, {
      isTranslating: true,
      progress: 0,
      error: null,
      translatedContent: "",
      translatedBlocks: []
    });

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
      const blocks = parseSrt(tab.originalContent);
      const chunkSize = settings.chunkSize;
      const chunks: SrtBlock[][] = [];
      
      for (let i = 0; i < blocks.length; i += chunkSize) {
        chunks.push(blocks.slice(i, i + chunkSize));
      }

      let finalResult = "";
      let allTranslatedBlocks: SrtBlock[] = [];

      const glossaryPrompt = glossary.length > 0 
        ? `\n\nSử dụng bảng thuật ngữ sau:\n${glossary.map(g => `- ${g.zh}: ${g.vi}`).join("\n")}`
        : "";

      for (let i = 0; i < chunks.length; i++) {
        const chunkText = stringifySrt(chunks[i]);
        const prompt = `${PROMPTS[tab.style]}${glossaryPrompt}\n\nNội dung cần dịch:\n${chunkText}`;

        const response = await ai.models.generateContent({
          model: MODEL_NAME,
          contents: prompt,
        });

        const translatedChunk = response.text || "";
        const cleanedChunk = translatedChunk.replace(/```srt|```/g, "").trim();
        finalResult += (finalResult ? "\n\n" : "") + cleanedChunk;
        
        const chunkBlocks = parseSrt(cleanedChunk);
        allTranslatedBlocks = [...allTranslatedBlocks, ...chunkBlocks];
        
        updateTab(tab.id, {
          progress: Math.round(((i + 1) / chunks.length) * 100),
          translatedContent: finalResult,
          translatedBlocks: allTranslatedBlocks
        });
      }

      // Add to history
      if (tab.file) {
        const newHistoryItem = {
          id: Math.random().toString(36).substr(2, 9),
          name: tab.file.name,
          date: new Date().toLocaleString(),
          size: (tab.file.size / 1024).toFixed(1) + " KB"
        };
        setHistory(prev => [newHistoryItem, ...prev].slice(0, 20));
        if (settings.autoDownload) {
          downloadSrt();
        }
      }
    } catch (err: any) {
      console.error("Translation error:", err);
      updateTab(tab.id, { error: "Đã xảy ra lỗi trong quá trình dịch. Vui lòng thử lại." });
    } finally {
      updateTab(tab.id, { isTranslating: false });
    }
  };

  const updateBlockContent = (index: number, newContent: string) => {
    const tab = currentTab;
    const newBlocks = [...tab.translatedBlocks];
    if (newBlocks[index]) {
      newBlocks[index].content = newContent;
      updateTab(tab.id, {
        translatedBlocks: newBlocks,
        translatedContent: stringifySrt(newBlocks)
      });
    }
  };

  const deleteBlockContent = (index: number) => {
    const tab = currentTab;
    const newBlocks = [...tab.translatedBlocks];
    if (newBlocks[index]) {
      newBlocks[index].content = "";
      updateTab(tab.id, {
        translatedBlocks: newBlocks,
        translatedContent: stringifySrt(newBlocks)
      });
    }
  };

  const downloadSrt = () => {
    const tab = currentTab;
    if (!tab.translatedContent) return;
    const blob = new Blob([tab.translatedContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = tab.file ? tab.file.name.replace(".srt", "_VN.srt") : "translated.srt";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const reset = () => {
    updateTab(activeTabId, {
      file: null,
      name: "Dịch thuật " + (tabs.findIndex(t => t.id === activeTabId) + 1),
      originalContent: "",
      translatedContent: "",
      progress: 0,
      error: null,
      originalBlocks: [],
      translatedBlocks: []
    });
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5] text-[#1A1A1A] font-sans selection:bg-[#FF6321] selection:text-white">
      {/* Header */}
      <header className="border-b border-black/10 bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#FF6321] rounded-xl flex items-center justify-center text-white shadow-lg shadow-[#FF6321]/20">
              <Languages size={24} />
            </div>
            <div>
              <h1 className="text-lg font-semibold tracking-tight">SRT Translator</h1>
              <p className="text-xs text-black/50 font-medium uppercase tracking-wider">Powered by Gemini AI</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setActiveTab("settings")}
              className={`p-2 hover:bg-black/5 rounded-full transition-colors ${activeTab === 'settings' ? 'text-[#FF6321] bg-black/5' : 'text-black/60'}`}
            >
              <Settings size={20} />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* Tabs Navigation */}
        <div className="flex items-center gap-1 bg-black/5 p-1 rounded-2xl w-fit mb-12 overflow-x-auto scrollbar-hide max-w-full">
          <button 
            onClick={() => setActiveTab("translate")}
            className={`px-6 py-2.5 rounded-xl text-sm font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === 'translate' ? 'bg-white shadow-sm text-[#FF6321]' : 'text-black/40 hover:text-black/60'}`}
          >
            <Languages size={18} />
            Dịch thuật
          </button>
          <button 
            onClick={() => setActiveTab("glossary")}
            className={`px-6 py-2.5 rounded-xl text-sm font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === 'glossary' ? 'bg-white shadow-sm text-[#FF6321]' : 'text-black/40 hover:text-black/60'}`}
          >
            <CheckCircle2 size={18} />
            Thuật ngữ
          </button>
          <button 
            onClick={() => setActiveTab("history")}
            className={`px-6 py-2.5 rounded-xl text-sm font-bold uppercase tracking-widest transition-all flex items-center gap-2 whitespace-nowrap ${activeTab === 'history' ? 'bg-white shadow-sm text-[#FF6321]' : 'text-black/40 hover:text-black/60'}`}
          >
            <HistoryIcon size={18} />
            Lịch sử
          </button>
        </div>

        <AnimatePresence mode="wait">
          {activeTab === "translate" && (
            <motion.div 
              key="translate"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-8"
            >
              {/* Sub-tabs for multiple translations */}
              <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide pb-2">
                {tabs.map((tab) => (
                  <div 
                    key={tab.id}
                    onClick={() => setActiveTabId(tab.id)}
                    className={`
                      flex items-center gap-3 px-4 py-2 rounded-xl border cursor-pointer transition-all whitespace-nowrap group
                      ${activeTabId === tab.id 
                        ? 'border-[#FF6321] bg-[#FF6321]/5 text-[#FF6321]' 
                        : 'border-black/5 bg-white text-black/40 hover:text-black/60'}
                    `}
                  >
                    <FileText size={14} />
                    <span className="text-xs font-bold uppercase tracking-wider truncate max-w-[120px]">{tab.name}</span>
                    <button 
                      onClick={(e) => closeTab(tab.id, e)}
                      className="p-1 hover:bg-black/5 rounded-md transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                ))}
                <button 
                  onClick={addTab}
                  className="p-2 bg-black/5 hover:bg-black/10 rounded-xl transition-colors text-black/40 flex items-center gap-2 px-4"
                  title="Thêm tab mới"
                >
                  <ChevronRight size={18} />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Thêm tab</span>
                </button>
              </div>

              <div className="grid lg:grid-cols-[1fr_400px] gap-12 items-start">
                {/* Left Column: Editor/Preview */}
                <div className="space-y-8">
                  <AnimatePresence mode="wait">
                    {!currentTab.file ? (
                      <motion.div
                        key="upload"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -20 }}
                        className={`
                          relative group border-2 border-dashed rounded-3xl p-12 transition-all duration-300
                          ${isDragging ? 'border-[#FF6321] bg-[#FF6321]/5' : 'border-black/10 bg-white hover:border-black/20'}
                        `}
                        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                        onDragLeave={() => setIsDragging(false)}
                        onDrop={handleDrop}
                      >
                        <input 
                          type="file" 
                          ref={fileInputRef}
                          onChange={handleFileChange}
                          accept=".srt"
                          className="hidden"
                        />
                        <div className="flex flex-col items-center text-center space-y-6">
                          <div className="w-20 h-20 bg-black/5 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                            <Upload size={32} className="text-black/40" />
                          </div>
                          <div className="space-y-2">
                            <h2 className="text-2xl font-semibold tracking-tight">Tải lên tệp phụ đề của bạn</h2>
                            <p className="text-black/50 max-w-sm mx-auto">
                              Kéo và thả tệp .srt tiếng Trung của bạn vào đây hoặc nhấp để chọn từ máy tính.
                            </p>
                          </div>
                          <button 
                            onClick={() => fileInputRef.current?.click()}
                            className="px-8 py-3 bg-black text-white rounded-full font-medium hover:bg-black/80 transition-all active:scale-95"
                          >
                            Chọn tệp .srt
                          </button>
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div
                        key="preview"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="bg-white rounded-3xl border border-black/10 shadow-sm overflow-hidden"
                      >
                        <div className="border-b border-black/5 px-6 py-4 flex items-center justify-between bg-black/[0.02]">
                          <div className="flex items-center gap-3">
                            <FileText size={18} className="text-[#FF6321]" />
                            <span className="font-medium text-sm truncate max-w-[200px]">{currentTab.file.name}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="flex bg-black/5 p-1 rounded-xl mr-4">
                              <button 
                                onClick={() => updateTab(currentTab.id, { viewMode: "comparison" })}
                                className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest rounded-lg transition-all ${currentTab.viewMode === 'comparison' ? 'bg-white shadow-sm text-black' : 'text-black/40 hover:text-black/60'}`}
                              >
                                So sánh
                              </button>
                              <button 
                                onClick={() => updateTab(currentTab.id, { viewMode: "raw" })}
                                className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-widest rounded-lg transition-all ${currentTab.viewMode === 'raw' ? 'bg-white shadow-sm text-black' : 'text-black/40 hover:text-black/60'}`}
                              >
                                Mã nguồn
                              </button>
                            </div>
                            <button 
                              onClick={reset}
                              className="p-2 hover:bg-red-50 text-red-500 rounded-lg transition-colors"
                              title="Xóa tệp"
                            >
                              <Trash2 size={18} />
                            </button>
                          </div>
                        </div>
                        
                        <div className="h-[600px] overflow-hidden flex flex-col">
                          {currentTab.viewMode === "raw" ? (
                            <div className="grid grid-cols-2 flex-1 overflow-hidden">
                              <div className="border-r border-black/5 flex flex-col">
                                <div className="px-4 py-2 bg-black/[0.01] border-b border-black/5 text-[10px] font-bold uppercase tracking-widest text-black/40">Gốc (Tiếng Trung)</div>
                                <div className="flex-1 overflow-hidden">
                                  <textarea
                                    value={currentTab.originalContent}
                                    onChange={(e) => {
                                      updateTab(currentTab.id, {
                                        originalContent: e.target.value,
                                        originalBlocks: parseSrt(e.target.value)
                                      });
                                    }}
                                    className="w-full h-full p-6 font-mono text-xs leading-relaxed text-black/60 whitespace-pre-wrap bg-transparent border-none focus:ring-0 focus:outline-none resize-none"
                                    placeholder="Dán nội dung .srt tiếng Trung vào đây..."
                                  />
                                </div>
                              </div>
                              <div className="flex flex-col bg-[#FAFAFA]">
                                <div className="px-4 py-2 bg-black/[0.01] border-b border-black/5 text-[10px] font-bold uppercase tracking-widest text-black/40">Bản dịch (Tiếng Việt)</div>
                                <div className="flex-1 overflow-hidden relative">
                                  {currentTab.isTranslating ? (
                                    <div className="h-full flex flex-col items-center justify-center space-y-4">
                                      <Loader2 className="animate-spin text-[#FF6321]" size={32} />
                                      <div className="text-center">
                                        <p className="font-medium text-black/80">Đang dịch...</p>
                                        <p className="text-[10px] text-black/40 uppercase tracking-widest">{currentTab.progress}% hoàn thành</p>
                                      </div>
                                    </div>
                                  ) : currentTab.translatedContent ? (
                                    <>
                                      <textarea
                                        value={currentTab.translatedContent}
                                        onChange={(e) => {
                                          updateTab(currentTab.id, {
                                            translatedContent: e.target.value,
                                            translatedBlocks: parseSrt(e.target.value)
                                          });
                                        }}
                                        className="w-full h-full p-6 font-mono text-xs leading-relaxed text-black/80 whitespace-pre-wrap bg-transparent border-none focus:ring-0 focus:outline-none resize-none"
                                      />
                                      {currentTab.translatedContent && (
                                        <button 
                                          onClick={() => {
                                            navigator.clipboard.writeText(currentTab.translatedContent);
                                          }}
                                          className="absolute top-4 right-4 p-2 bg-white shadow-sm border border-black/5 rounded-lg text-black/40 hover:text-[#FF6321] transition-all"
                                          title="Sao chép nội dung"
                                        >
                                          <Languages size={14} />
                                        </button>
                                      )}
                                    </>
                                  ) : (
                                    <div className="h-full flex flex-col items-center justify-center text-black/30 italic">
                                      Nhấn "Bắt đầu dịch" để xem kết quả
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="flex-1 overflow-y-auto bg-white">
                              <div className="sticky top-0 z-10 grid grid-cols-[80px_1fr_1fr] bg-black text-[10px] font-bold uppercase tracking-widest text-white/60 border-b border-white/10">
                                <div className="px-4 py-3 border-r border-white/10">STT</div>
                                <div className="px-4 py-3 border-r border-white/10">Tiếng Trung</div>
                                <div className="px-4 py-3">Tiếng Việt</div>
                              </div>
                              {currentTab.originalBlocks.map((block, idx) => {
                                const translated = currentTab.translatedBlocks[idx];
                                return (
                                  <div key={idx} className="grid grid-cols-[80px_1fr_1fr] border-b border-black/5 hover:bg-black/[0.01] transition-colors group">
                                    <div className="px-4 py-6 border-r border-black/5 text-center">
                                      <span className="text-[10px] font-bold text-black/20 group-hover:text-[#FF6321] transition-colors">{block.index}</span>
                                      <div className="mt-2 text-[8px] text-black/30 font-mono leading-tight">
                                        {settings.showTimestamps ? block.time.split(' --> ').join('\n') : ''}
                                      </div>
                                    </div>
                                    <div className="px-6 py-6 border-r border-black/5 text-sm text-black/60 leading-relaxed">
                                      {block.content}
                                    </div>
                                    <div className={`px-6 py-4 text-sm leading-relaxed relative group/cell ${translated ? 'text-black' : 'text-black/20 italic'}`}>
                                      {currentTab.isTranslating && idx >= currentTab.translatedBlocks.length ? (
                                        <div className="flex items-center gap-2 text-black/30 h-full">
                                          <Loader2 size={12} className="animate-spin" />
                                          <span className="text-[10px] uppercase tracking-widest font-bold">Đang dịch...</span>
                                        </div>
                                      ) : translated ? (
                                        <div className="relative">
                                          <textarea
                                            value={translated.content}
                                            onChange={(e) => updateBlockContent(idx, e.target.value)}
                                            className="w-full bg-transparent border-none focus:ring-0 focus:outline-none resize-none p-0 min-h-[60px] scrollbar-hide"
                                            rows={2}
                                          />
                                          <button 
                                            onClick={() => deleteBlockContent(idx)}
                                            className="absolute -right-2 -top-2 p-1.5 bg-white shadow-sm border border-black/5 rounded-lg text-red-400 hover:text-red-500 opacity-0 group-hover/cell:opacity-100 transition-all hover:scale-110"
                                            title="Xóa nội dung"
                                          >
                                            <Trash2 size={12} />
                                          </button>
                                        </div>
                                      ) : (
                                        "Chưa dịch"
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {currentTab.error && (
                    <motion.div 
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600 text-sm"
                    >
                      <AlertCircle size={18} />
                      {currentTab.error}
                    </motion.div>
                  )}
                </div>

                {/* Right Column: Controls */}
                <aside className="space-y-6 lg:sticky lg:top-28">
                  <div className="bg-white rounded-3xl border border-black/10 p-8 space-y-8">
                    <div className="space-y-4">
                      <h3 className="text-sm font-bold uppercase tracking-widest text-black/40">Cấu hình dịch thuật</h3>
                      <div className="space-y-3">
                        {(["basic", "advanced", "technical"] as TranslationStyle[]).map((s) => (
                          <button
                            key={s}
                            onClick={() => updateTab(currentTab.id, { style: s })}
                            className={`
                              w-full flex items-center justify-between p-4 rounded-2xl border transition-all text-left
                              ${currentTab.style === s 
                                ? 'border-[#FF6321] bg-[#FF6321]/5 text-[#FF6321]' 
                                : 'border-black/5 hover:border-black/10 bg-white text-black/60'}
                            `}
                          >
                            <div className="space-y-1">
                              <p className="font-semibold capitalize">{s === 'basic' ? 'Cơ bản' : s === 'advanced' ? 'Nâng cao (Phim)' : 'Chuyên ngành'}</p>
                              <p className="text-[10px] opacity-70">
                                {s === 'basic' ? 'Dịch nhanh, sát nghĩa' : s === 'advanced' ? 'Văn phong tự nhiên, xưng hô chuẩn' : 'Chính xác thuật ngữ'}
                              </p>
                            </div>
                            {currentTab.style === s && <CheckCircle2 size={18} />}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="pt-6 border-t border-black/5 space-y-4">
                      <button
                        disabled={!currentTab.file || currentTab.isTranslating}
                        onClick={translate}
                        className={`
                          w-full py-4 rounded-full font-bold text-sm uppercase tracking-widest flex items-center justify-center gap-3 transition-all
                          ${!currentTab.file || currentTab.isTranslating 
                            ? 'bg-black/5 text-black/20 cursor-not-allowed' 
                            : 'bg-[#FF6321] text-white hover:bg-[#E5591D] shadow-lg shadow-[#FF6321]/20 active:scale-95'}
                        `}
                      >
                        {currentTab.isTranslating ? (
                          <>
                            <Loader2 size={18} className="animate-spin" />
                            Đang xử lý...
                          </>
                        ) : (
                          <>
                            <Play size={18} fill="currentColor" />
                            Bắt đầu dịch
                          </>
                        )}
                      </button>

                      {currentTab.translatedContent && (
                        <button
                          onClick={downloadSrt}
                          className="w-full py-4 rounded-full border-2 border-black text-black font-bold text-sm uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-black hover:text-white transition-all active:scale-95"
                        >
                          <Download size={18} />
                          Tải xuống .srt
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="bg-black rounded-3xl p-8 text-white space-y-4 overflow-hidden relative group">
                    <div className="relative z-10 space-y-2">
                      <h4 className="font-bold text-sm">Mẹo nhỏ</h4>
                      <p className="text-xs text-white/60 leading-relaxed">
                        Nếu tệp của bạn quá dài, chúng tôi sẽ tự động chia nhỏ để đảm bảo chất lượng dịch thuật tốt nhất từ Gemini.
                      </p>
                    </div>
                    <div className="absolute -right-4 -bottom-4 opacity-10 group-hover:scale-110 transition-transform duration-500">
                      <Languages size={120} />
                    </div>
                  </div>
                </aside>
              </div>
            </motion.div>
          )}

          {activeTab === "glossary" && (
            <motion.div 
              key="glossary"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="max-w-4xl mx-auto space-y-8"
            >
              <div className="bg-white rounded-3xl border border-black/10 p-10 space-y-8">
                <div className="space-y-4">
                  <h2 className="text-3xl font-bold tracking-tight">Bảng thuật ngữ</h2>
                  <p className="text-black/50">Định nghĩa các từ ngữ chuyên ngành để Gemini dịch chính xác hơn theo ý bạn.</p>
                </div>

                <div className="grid grid-cols-[1fr_1fr_100px] gap-4 items-end bg-[#F5F5F5] p-6 rounded-2xl">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-black/40">Tiếng Trung</label>
                    <input 
                      id="zh-input"
                      type="text" 
                      placeholder="VD: 仙侠" 
                      className="w-full px-4 py-3 bg-white border border-black/5 rounded-xl text-sm focus:ring-2 focus:ring-[#FF6321] focus:outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-black/40">Tiếng Việt</label>
                    <input 
                      id="vi-input"
                      type="text" 
                      placeholder="VD: Tiên hiệp" 
                      className="w-full px-4 py-3 bg-white border border-black/5 rounded-xl text-sm focus:ring-2 focus:ring-[#FF6321] focus:outline-none"
                    />
                  </div>
                  <button 
                    onClick={() => {
                      const zh = (document.getElementById('zh-input') as HTMLInputElement).value;
                      const vi = (document.getElementById('vi-input') as HTMLInputElement).value;
                      if (zh && vi) {
                        setGlossary([...glossary, { zh, vi }]);
                        (document.getElementById('zh-input') as HTMLInputElement).value = '';
                        (document.getElementById('vi-input') as HTMLInputElement).value = '';
                      }
                    }}
                    className="h-11 bg-black text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-black/80 transition-all active:scale-95"
                  >
                    Thêm
                  </button>
                </div>

                <div className="space-y-4">
                  {glossary.length > 0 ? (
                    <div className="border border-black/5 rounded-2xl overflow-hidden">
                      <table className="w-full text-left">
                        <thead className="bg-black/[0.02] border-b border-black/5">
                          <tr>
                            <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-black/40">Tiếng Trung</th>
                            <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-black/40">Tiếng Việt</th>
                            <th className="px-6 py-4 text-[10px] font-bold uppercase tracking-widest text-black/40 text-right">Hành động</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-black/5">
                          {glossary.map((item, i) => (
                            <tr key={i} className="hover:bg-black/[0.01] transition-colors">
                              <td className="px-6 py-4 font-medium">{item.zh}</td>
                              <td className="px-6 py-4 text-black/60">{item.vi}</td>
                              <td className="px-6 py-4 text-right">
                                <button 
                                  onClick={() => setGlossary(glossary.filter((_, idx) => idx !== i))}
                                  className="p-2 hover:bg-red-50 text-red-400 rounded-lg transition-colors"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="py-12 text-center bg-black/[0.01] rounded-2xl border border-dashed border-black/10">
                      <p className="text-sm text-black/30 italic">Chưa có thuật ngữ nào được thêm.</p>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === "settings" && (
            <motion.div 
              key="settings"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="max-w-4xl mx-auto space-y-8"
            >
              <div className="bg-white rounded-3xl border border-black/10 p-10 space-y-12">
                <div className="space-y-4">
                  <h2 className="text-3xl font-bold tracking-tight">Cài đặt hệ thống</h2>
                  <p className="text-black/50">Tùy chỉnh trải nghiệm dịch thuật của bạn.</p>
                </div>

                <div className="space-y-8">
                  <div className="flex items-center justify-between p-6 bg-[#F5F5F5] rounded-2xl">
                    <div className="space-y-1">
                      <h3 className="font-bold">Số dòng mỗi lượt dịch</h3>
                      <p className="text-xs text-black/40">Chia nhỏ tệp để Gemini xử lý tốt hơn (mặc định: 50).</p>
                    </div>
                    <select 
                      value={settings.chunkSize}
                      onChange={(e) => setSettings({ ...settings, chunkSize: parseInt(e.target.value) })}
                      className="bg-white border border-black/5 px-4 py-2 rounded-xl text-sm font-bold focus:outline-none"
                    >
                      <option value="20">20 dòng</option>
                      <option value="50">50 dòng</option>
                      <option value="100">100 dòng</option>
                    </select>
                  </div>

                  <div className="flex items-center justify-between p-6 bg-[#F5F5F5] rounded-2xl">
                    <div className="space-y-1">
                      <h3 className="font-bold">Tự động tải xuống</h3>
                      <p className="text-xs text-black/40">Tự động tải tệp .srt sau khi dịch xong.</p>
                    </div>
                    <button 
                      onClick={() => setSettings({ ...settings, autoDownload: !settings.autoDownload })}
                      className={`w-12 h-6 rounded-full transition-all relative ${settings.autoDownload ? 'bg-[#FF6321]' : 'bg-black/10'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.autoDownload ? 'left-7' : 'left-1'}`} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-6 bg-[#F5F5F5] rounded-2xl">
                    <div className="space-y-1">
                      <h3 className="font-bold">Hiển thị mốc thời gian</h3>
                      <p className="text-xs text-black/40">Hiển thị thời gian trong chế độ so sánh.</p>
                    </div>
                    <button 
                      onClick={() => setSettings({ ...settings, showTimestamps: !settings.showTimestamps })}
                      className={`w-12 h-6 rounded-full transition-all relative ${settings.showTimestamps ? 'bg-[#FF6321]' : 'bg-black/10'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.showTimestamps ? 'left-7' : 'left-1'}`} />
                    </button>
                  </div>
                </div>

                <div className="pt-8 border-t border-black/5 flex justify-end">
                  <button 
                    onClick={() => {
                      if (confirm("Bạn có chắc chắn muốn xóa toàn bộ lịch sử và thuật ngữ?")) {
                        setHistory([]);
                        setGlossary([]);
                        localStorage.removeItem("srt_history");
                        localStorage.removeItem("srt_glossary");
                      }
                    }}
                    className="px-6 py-3 bg-red-50 text-red-500 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-red-100 transition-all"
                  >
                    Xóa toàn bộ dữ liệu
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === "history" && (
            <motion.div 
              key="history"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="max-w-4xl mx-auto"
            >
              <div className="bg-white rounded-3xl border border-black/10 overflow-hidden">
                <div className="p-8 border-b border-black/5 flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold tracking-tight">Lịch sử dịch thuật</h2>
                    <p className="text-sm text-black/40">Danh sách các tệp bạn đã xử lý gần đây.</p>
                  </div>
                  {history.length > 0 && (
                    <button 
                      onClick={() => {
                        if (confirm("Xóa toàn bộ lịch sử?")) {
                          setHistory([]);
                          localStorage.removeItem("srt_history");
                        }
                      }}
                      className="text-[10px] font-bold uppercase tracking-widest text-red-500 hover:text-red-600 transition-colors"
                    >
                      Xóa tất cả
                    </button>
                  )}
                </div>
                {history.length > 0 ? (
                  <div className="divide-y divide-black/5">
                    {history.map((item, i) => (
                      <div key={item.id || i} className="p-6 flex items-center justify-between hover:bg-black/[0.01] transition-colors group">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-[#FF6321]/5 rounded-2xl flex items-center justify-center text-[#FF6321]">
                            <FileText size={24} />
                          </div>
                          <div>
                            <p className="font-bold text-black/80">{item.name}</p>
                            <div className="flex items-center gap-3 mt-1">
                              <div className="flex items-center gap-1 text-[10px] text-black/30 font-bold uppercase tracking-widest">
                                <Clock size={10} />
                                {item.date}
                              </div>
                              <div className="w-1 h-1 bg-black/10 rounded-full" />
                              <div className="text-[10px] text-black/30 font-bold uppercase tracking-widest">
                                {item.size}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button 
                            onClick={() => setHistory(history.filter(h => h.id !== item.id))}
                            className="p-3 hover:bg-red-50 text-red-400 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                            title="Xóa khỏi lịch sử"
                          >
                            <Trash2 size={18} />
                          </button>
                          <button className="p-3 hover:bg-black/5 rounded-xl transition-colors text-black/40">
                            <ChevronRight size={20} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-20 flex flex-col items-center justify-center text-center space-y-4">
                    <div className="w-16 h-16 bg-black/5 rounded-full flex items-center justify-center text-black/20">
                      <HistoryIcon size={32} />
                    </div>
                    <div className="space-y-1">
                      <p className="font-bold text-black/40">Chưa có lịch sử</p>
                      <p className="text-xs text-black/30">Các tệp bạn dịch sẽ xuất hiện tại đây.</p>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-black/5">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 text-[10px] font-bold uppercase tracking-widest text-black/30">
          <p>© 2026 SRT Translator AI</p>
          <div className="flex items-center gap-8">
            <a href="#" className="hover:text-black transition-colors">Điều khoản</a>
            <a href="#" className="hover:text-black transition-colors">Bảo mật</a>
            <a href="#" className="hover:text-black transition-colors">Hỗ trợ</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
